import 'package:flutter/cupertino.dart';

class ConstKey {
  static const Key Name = Key("name");
  static const Key Email = Key("email");
  static const Key Password = Key("password");
  static const Key Phone = Key("phone");
  static const Key SignUp = Key("signUp");
}
